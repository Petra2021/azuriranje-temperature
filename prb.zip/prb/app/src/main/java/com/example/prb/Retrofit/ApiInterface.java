package com.example.prb.Retrofit;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("weather?appid=5d3d6e2a492e9e2bf7d4cd9511c2c60c&units=metric")
    Call<Example>getWeatherData(@Query("q") String name);
}
